import 'package:flutter/material.dart';
import '../models/question_model.dart';

class QuestionWidget extends StatelessWidget {
  final QuestionModel question;
  final Function(String) onAnswer;

  const QuestionWidget({super.key, required this.question, required this.onAnswer});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(question.question, style: const TextStyle(fontSize: 20)),
        const SizedBox(height: 20),
        ...question.options.map((opt) => ElevatedButton(
          onPressed: () => onAnswer(opt),
          child: Text(opt),
        )),
      ],
    );
  }
}
