// lib/config/app_config.dart
/// Centralized app configuration.
///
/// Provide API_BASE_URL at runtime for web/dev like:
/// flutter run -d chrome --web-renderer html \
///   --dart-define=API_BASE_URL=https://your-real-api.com/api
///
class AppConfig {
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://localhost:3000/api',
  );
}
