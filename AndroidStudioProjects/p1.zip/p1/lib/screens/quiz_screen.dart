import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import '../models/question_model.dart';
import '../services/database_service.dart';
import '../services/auth_service.dart';
import 'result_screen.dart';

class QuizScreen extends StatefulWidget {
  final String subjectId;
  final String? subjectName;

  const QuizScreen({
    super.key,
    required this.subjectId,
    this.subjectName,
  });

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  final _dbService = DatabaseService();
  final _authService = AuthService();

  List<QuestionModel> questions = [];
  int currentIndex = 0;
  int score = 0;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadQuestions();
  }

  void _loadQuestions() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final data = await _dbService
          .getQuestions(widget.subjectId)
          .timeout(const Duration(seconds: 12));

      if (!mounted) return;

      setState(() {
        questions = data
            .map((q) => QuestionModel(
                  id: q['id']?.toString() ?? '',
                  question: q['question']?.toString() ?? 'No question text',
                  options: List<String>.from(q['options'] ?? []),
                  correctAnswer: q['correctAnswer']?.toString() ?? '',
                  subjectId: widget.subjectId,
                ))
            .toList();
        _isLoading = false;
      });
    } on TimeoutException {
      if (!mounted) return;
      setState(() {
        _error = 'Request timed out. Please check your connection and try again.';
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('Error loading questions: $e');
      if (!mounted) return;
      setState(() {
        _error = 'Failed to load questions.';
        _isLoading = false;
      });
    }
  }

  void _answer(String selected) {
    if (questions[currentIndex].correctAnswer == selected) {
      score++;
    }

    if (currentIndex < questions.length - 1) {
      setState(() {
        currentIndex++;
      });
    } else {
      // Save result in Firestore
      _dbService.saveQuizResult({
        'userId': _authService.currentUser!.uid,
        'subjectId': widget.subjectId,
        'score': score,
      });

      // Navigate to Result Screen
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => ResultScreen(
              subjectId: widget.subjectId,
              subjectName: widget.subjectName ?? 'Quiz',
              score: score,
              totalQuestions: questions.length,
            ),
          ),
        );
      }
    }
  }

  Future<void> _seedAndReload() async {
    try {
      await _dbService.seedSampleQuestions(widget.subjectId);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sample questions added.')),
      );
      _loadQuestions();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to add sample questions: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.subjectName ?? 'Quiz')),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 56, color: Colors.red),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Text(
                  _error!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.red),
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _loadQuestions,
                child: const Text('Try Again'),
              ),
            ],
          ),
        ),
      );
    }

    if (questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.subjectName ?? 'Quiz')),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('No questions available for this subject yet.'),
              if (kDebugMode) ...[
                const SizedBox(height: 12),
                ElevatedButton(
                  onPressed: _seedAndReload,
                  child: const Text('Seed Sample Questions'),
                ),
              ],
            ],
          ),
        ),
      );
    }

    final q = questions[currentIndex];
    return Scaffold(
      appBar: AppBar(title: Text(widget.subjectName ?? 'Quiz')),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.15),
              Theme.of(context).colorScheme.secondary.withOpacity(0.15),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Progress indicator
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Chip(
                      label: Text('Question ${currentIndex + 1} / ${questions.length}'),
                      backgroundColor:
                          Theme.of(context).colorScheme.primary.withOpacity(0.1),
                    ),
                    Text(
                      'Score: $score',
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Centered question card
                Expanded(
                  child: Center(
                    child: Card(
                      elevation: 4,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 26,
                        ),
                        child: Text(
                          q.question,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 8),

                // Colorful full-width options
                ...List.generate(q.options.length, (index) {
                  final opt = q.options[index];
                  final palette = <Color>[
                    Colors.teal,
                    Colors.deepPurple,
                    Colors.orange,
                    Colors.pink,
                    Colors.indigo,
                  ];
                  final color = palette[index % palette.length];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: color,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                            vertical: 14,
                            horizontal: 16,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        onPressed: () => _answer(opt),
                        child: Text(
                          opt,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 16),
                        ),
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }
}