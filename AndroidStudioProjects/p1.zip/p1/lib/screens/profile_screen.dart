import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import '../services/auth_service.dart';
import '../services/user_service.dart';
import '../models/quiz_result.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<AuthService>(context).currentUser;
    if (user == null) {
      return const Scaffold(
        body: Center(child: Text('Please sign in to view your profile')),
      );
    }

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('My Profile'),
          bottom: const TabBar(
            tabs: [
              Tab(icon: Icon(Icons.assessment), text: 'Stats'),
              Tab(icon: Icon(Icons.history), text: 'History'),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.logout),
              onPressed: () => _signOut(context),
            ),
          ],
        ),
        body: TabBarView(
          children: [
            _buildStatsTab(context, user.uid),
            _buildHistoryTab(context, user.uid),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsTab(BuildContext context, String userId) {
    final userService = UserService();
    
    return FutureBuilder<Map<String, dynamic>>(
      future: userService.getUserStats(userId),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(
            child: Text('Error loading stats: ${snapshot.error}'),
          );
        }

        final stats = snapshot.data ?? {
          'totalQuizzes': 0,
          'averageScore': 0,
          'totalCorrect': 0,
          'totalQuestions': 0,
          'successRate': 0,
        };

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              _buildStatCard(
                context,
                title: 'Quizzes Taken',
                value: '${stats['totalQuizzes']}',
                icon: Icons.quiz,
                color: Colors.blue,
              ),
              const SizedBox(height: 16),
              _buildStatCard(
                context,
                title: 'Average Score',
                value: '${stats['averageScore']}%',
                icon: Icons.star,
                color: Colors.amber,
              ),
              const SizedBox(height: 16),
              _buildStatCard(
                context,
                title: 'Success Rate',
                value: '${stats['successRate']}%',
                icon: Icons.trending_up,
                color: Colors.green,
              ),
              const SizedBox(height: 16),
              _buildStatCard(
                context,
                title: 'Total Questions',
                value: '${stats['totalQuestions']}',
                icon: Icons.question_answer,
                color: Colors.purple,
              ),
              const SizedBox(height: 16),
              _buildStatCard(
                context,
                title: 'Correct Answers',
                value: '${stats['totalCorrect']}',
                icon: Icons.check_circle,
                color: Colors.green,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildHistoryTab(BuildContext context, String userId) {
    final userService = UserService();
    
    return StreamBuilder<List<QuizResult>>(
      stream: userService.getUserQuizHistory(userId),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(
            child: Text('Error loading history: ${snapshot.error}'),
          );
        }

        final results = snapshot.data ?? [];

        if (results.isEmpty) {
          return const Center(
            child: Text('No quiz history available'),
          );
        }

        return ListView.builder(
          itemCount: results.length,
          itemBuilder: (context, index) {
            final result = results[index];
            final date = DateFormat('MMM d, y - hh:mm a').format(result.timestamp);

            return Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: ListTile(
                title: Text(result.subjectName),
                subtitle: Text(date),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '${result.score}/${result.totalQuestions}',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    Text(
                      '${result.percentage}%',
                      style: TextStyle(
                        color: _getPercentageColor(result.percentage),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                onTap: () {
                  // Navigate to detailed result view if needed
                },
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildStatCard(
    BuildContext context, {
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  title,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Colors.grey[600],
                      ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Color _getPercentageColor(int percentage) {
    if (percentage >= 80) return Colors.green;
    if (percentage >= 60) return Colors.blue;
    if (percentage >= 40) return Colors.orange;
    return Colors.red;
  }

  Future<void> _signOut(BuildContext context) async {
    try {
      await Provider.of<AuthService>(context, listen: false).signOut();
      if (context.mounted) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          '/login',
          (route) => false,
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error signing out: $e')),
        );
      }
    }
  }
}
