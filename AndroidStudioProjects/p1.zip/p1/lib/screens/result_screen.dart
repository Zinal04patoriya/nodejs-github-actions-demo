import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import '../services/user_service.dart';
import 'subject_selection_screen.dart';
import 'quiz_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ResultScreen extends StatelessWidget {
  final String subjectId;
  final String? subjectName;
  final int score;
  final int totalQuestions;

  const ResultScreen({
    super.key,
    required this.subjectId,
    required this.subjectName,
    required this.score,
    required this.totalQuestions,
  });

  double get percentage => totalQuestions > 0 ? (score / totalQuestions) * 100 : 0;
  String get resultMessage {
    if (percentage >= 80) return 'Excellent Work!';
    if (percentage >= 60) return 'Good Job!';
    if (percentage >= 40) return 'Keep Practicing!';
    return 'Try Again!';
  }

  Color get resultColor {
    if (percentage >= 80) return Colors.green;
    if (percentage >= 60) return Colors.lightGreen;
    if (percentage >= 40) return Colors.orange;
    return Colors.red;
  }

  Future<void> _saveQuizResult(BuildContext context) async {
    final user = Provider.of<AuthService>(context, listen: false).currentUser;
    if (user == null) return;

    try {
      final userService = UserService();
      await userService.saveQuizResult(
        userId: user.uid,
        subjectId: subjectId,
        subjectName: subjectName ?? 'Quiz',
        score: score,
        totalQuestions: totalQuestions,
      );
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to save quiz result. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<AuthService>(context).currentUser;
    final theme = Theme.of(context);
    
    // Save the result when the screen is first built
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (user != null) {
        _saveQuizResult(context);
      }
    });
    
    return Scaffold(
      appBar: AppBar(
        title: Text('${subjectName ?? 'Quiz'} Results'),
        centerTitle: true,
        elevation: 0,
        backgroundColor: theme.scaffoldBackgroundColor,
        foregroundColor: theme.primaryColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 20),
            // Result Circle with animation
            TweenAnimationBuilder<double>(
              duration: const Duration(milliseconds: 1500),
              curve: Curves.easeOutCubic,
              tween: Tween(begin: 0.0, end: percentage / 100),
              builder: (context, value, _) {
                return Container(
                  width: 200,
                  height: 200,
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Background circle
                      SizedBox(
                        width: 180,
                        height: 180,
                        child: CircularProgressIndicator(
                          value: value,
                          strokeWidth: 12,
                          backgroundColor: Colors.grey[200],
                          valueColor: AlwaysStoppedAnimation<Color>(resultColor),
                        ),
                      ),
                      // Score text
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '${(value * 100).round()}%',
                            style: TextStyle(
                              fontSize: 36,
                              fontWeight: FontWeight.bold,
                              color: theme.primaryColor,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '${(value * totalQuestions).round()} / $totalQuestions',
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
            
            // Result message with icon
            Container(
              margin: const EdgeInsets.symmetric(vertical: 16),
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
              decoration: BoxDecoration(
                color: resultColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: resultColor.withOpacity(0.2)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _getResultIcon(),
                    color: resultColor,
                    size: 24,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    resultMessage,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: resultColor,
                    ),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 24),
            // Score details
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: BorderSide(color: Colors.grey.shade200),
              ),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Quiz Summary',
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: theme.primaryColor,
                      ),
                    ),
                    const Divider(height: 32, thickness: 1),
                    _buildScoreRow(
                      'Correct Answers',
                      score,
                      Colors.green,
                      icon: Icons.check_circle_outline,
                    ),
                    const SizedBox(height: 12),
                    _buildScoreRow(
                      'Incorrect Answers',
                      totalQuestions - score,
                      Colors.red,
                      icon: Icons.highlight_off_outlined,
                    ),
                    const SizedBox(height: 12),
                    _buildScoreRow(
                      'Total Questions',
                      totalQuestions,
                      theme.primaryColor,
                      isBold: true,
                      icon: Icons.help_outline,
                    ),
                    const SizedBox(height: 8),
                    _buildScoreRow(
                      'Success Rate',
                      percentage.round(),
                      _getSuccessRateColor(percentage),
                      isPercentage: true,
                      icon: Icons.trending_up,
                    ),
                  ],
                ),
              ),
            ),
            // Action Buttons
            ElevatedButton(
              onPressed: () {
                // Restart the quiz
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => QuizScreen(
                      subjectId: subjectId,
                      subjectName: subjectName,
                    ),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                textStyle: const TextStyle(fontSize: 18),
              ),
              child: const Text('Restart Quiz'),
            ),
            const SizedBox(height: 16),
            OutlinedButton(
              onPressed: () {
                // Go back to subject selection
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const SubjectSelectionScreen(),
                  ),
                  (route) => false,
                );
              },
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                textStyle: const TextStyle(fontSize: 18),
              ),
              child: const Text('Choose Another Subject'),
            ),
            if (user != null) ...{
              const SizedBox(height: 16),
              // TODO: Add functionality to save score to user's profile
              TextButton(
                onPressed: () {
                  // Save score to user's profile
                  // This would typically be handled by a UserService
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Score saved to your profile!'),
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
                child: const Text('Save Score to Profile'),
              ),
            },
          ],
        ),
      ),
    );
  }

  Widget _buildScoreRow(
    String label, 
    int value, 
    Color color, {
    bool isBold = false,
    bool isPercentage = false,
    IconData? icon,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Icon(icon, size: 20, color: Colors.grey[600]),
                const SizedBox(width: 8),
              ],
              Text(
                label,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
                  color: Colors.grey[800],
                ),
              ),
            ],
          ),
          Text(
            isPercentage ? '$value%' : value.toString(),
            style: TextStyle(
              fontSize: 16,
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  IconData _getResultIcon() {
    if (percentage >= 80) return Icons.emoji_events;
    if (percentage >= 60) return Icons.thumb_up;
    if (percentage >= 40) return Icons.psychology;
    return Icons.refresh;
  }

  Color _getSuccessRateColor(double percentage) {
    if (percentage >= 80) return Colors.green;
    if (percentage >= 60) return Colors.blue;
    if (percentage >= 40) return Colors.orange;
    return Colors.red;
  }
}
