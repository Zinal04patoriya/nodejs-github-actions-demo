// services/firestore_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Get all subjects from Firestore
  Future<List<Map<String, dynamic>>> getSubjects() async {
    try {
      QuerySnapshot querySnapshot = await _firestore.collection('subjects').get();

      List<Map<String, dynamic>> subjects = [];
      for (var doc in querySnapshot.docs) {
        subjects.add({
          'id': doc.id,
          'name': doc['name'] ?? 'No Name',
          'description': doc['description'] ?? 'No Description',
        });
      }

      return subjects;
    } catch (e) {
      print('Error getting subjects: $e');
      throw Exception('Failed to load subjects: $e');
    }
  }

  // Add sample data if collection is empty
  Future<void> initializeSampleData() async {
    try {
      final subjectsSnapshot = await _firestore.collection('subjects').get();

      if (subjectsSnapshot.docs.isEmpty) {
        // Add sample subjects
        await _firestore.collection('subjects').add({
          'name': 'Mathematics',
          'description': 'Test your math skills',
          'createdAt': FieldValue.serverTimestamp(),
        });

        await _firestore.collection('subjects').add({
          'name': 'Science',
          'description': 'Science knowledge test',
          'createdAt': FieldValue.serverTimestamp(),
        });

        await _firestore.collection('subjects').add({
          'name': 'History',
          'description': 'Historical facts and events',
          'createdAt': FieldValue.serverTimestamp(),
        });

        print('Sample subjects added to Firestore');
      }
    } catch (e) {
      print('Error initializing data: $e');
    }
  }
}