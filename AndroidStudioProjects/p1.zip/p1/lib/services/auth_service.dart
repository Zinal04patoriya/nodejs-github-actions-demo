import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../models/user_model.dart';
import 'firestore_service.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  static const String _userKey = 'user_data';
  
  // Stream to track authentication state changes
  Stream<User?> get authStateChanges => _auth.authStateChanges();
  
  // Get current user
  User? get currentUser => _auth.currentUser;
  
  // Get current user ID
  String? get currentUserId => _auth.currentUser?.uid;

  /// Register user with email & password, then save profile to Firestore
  Future<UserModel> register(String name, String email, String password) async {
    try {
      // Create user in Firebase Auth
      UserCredential cred = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = cred.user;
      
      if (user == null) {
        throw Exception('Failed to create user');
      }

      // Update display name in Firebase Auth profile
      await user.updateDisplayName(name);
      await user.reload();
      user = _auth.currentUser;

      // Create user profile in Firestore
      final newUser = UserModel(
        uid: user!.uid,
        name: name,
        email: email,
        createdAt: DateTime.now(),
        totalScore: 0,
        lastLogin: DateTime.now(),
        photoUrl: user.photoURL,
      );

      await _db.collection('users').doc(user.uid).set(newUser.toMap());
      
      // Save user data locally
      await _saveUserData(newUser);
      
      return newUser;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw Exception('Registration failed: $e');
    }
  }

  /// Login user with email & password
  Future<UserModel> login(String email, String password) async {
    try {
      final cred = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      if (cred.user == null) {
        throw Exception('User not found');
      }
      
      // Get user data from Firestore
      final userDoc = await _db.collection('users').doc(cred.user!.uid).get();
      
      if (!userDoc.exists) {
        throw Exception('User data not found');
      }
      
      final userData = UserModel.fromMap(userDoc.data()!);
      
      // Update last login
      await _db.collection('users').doc(cred.user!.uid).update({
        'lastLogin': FieldValue.serverTimestamp(),
      });
      
      // Save user data locally
      await _saveUserData(userData);
      
      return userData;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw Exception('Login failed: $e');
    }
  }

  /// Logout current user
  Future<void> logout() async {
    try {
      await _auth.signOut();
      await _secureStorage.deleteAll();
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_userKey);
    } catch (e) {
      throw Exception('Logout failed: $e');
    }
  }

  /// Sign out the current user (alias for logout)
  Future<void> signOut() async {
    return logout();
  }

  /// Get current user data
  Future<UserModel?> getCurrentUser() async {
    try {
      // Try to get from secure storage first
      final email = await _secureStorage.read(key: 'user_email');
      if (email == null) return null;
      
      // Get from Firestore
      final userDocs = await _db
          .collection('users')
          .where('email', isEqualTo: email)
          .limit(1)
          .get();
          
      if (userDocs.docs.isEmpty) return null;
      
      return UserModel.fromMap(userDocs.docs.first.data());
    } catch (e) {
      return null;
    }
  }

  /// Check if user is logged in
  Future<bool> isLoggedIn() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return false;
      
      // Verify token is still valid
      await user.getIdTokenResult(true);
      return true;
    } catch (e) {
      return false;
    }
  }

  /// Reset password
  Future<void> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw Exception('Failed to send password reset email: $e');
    }
  }

  // Save user data to secure storage
  Future<void> _saveUserData(UserModel user) async {
    try {
      // Save sensitive data in secure storage
      await _secureStorage.write(key: 'user_email', value: user.email);
      
      // Save basic user data in shared preferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_userKey, user.toJson().toString());
    } catch (e) {
      throw Exception('Failed to save user data: $e');
    }
  }

  // Handle Firebase Auth exceptions
  Exception _handleAuthException(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return Exception('No user found with this email.');
      case 'wrong-password':
        return Exception('Incorrect password.');
      case 'email-already-in-use':
        return Exception('Email already in use.');
      case 'weak-password':
        return Exception('Password is too weak.');
      case 'invalid-email':
        return Exception('Email address is not valid.');
      case 'user-disabled':
        return Exception('This account has been disabled.');
      case 'too-many-requests':
        return Exception('Too many requests. Please try again later.');
      default:
        return Exception('Authentication error: ${e.message}');
    }
  }
}
