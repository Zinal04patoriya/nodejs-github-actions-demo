// services/database_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class DatabaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Get user data
  Future<Map<String, dynamic>?> getUserData(String userId) async {
    try {
      DocumentSnapshot doc = await _firestore.collection('users').doc(userId).get();
      return doc.data() as Map<String, dynamic>?;
    } catch (e) {
      print('Error getting user data: $e');
      return null;
    }
  }

  // Save user data
  Future<void> saveUserData(String userId, Map<String, dynamic> userData) async {
    try {
      await _firestore.collection('users').doc(userId).set(userData);
    } catch (e) {
      print('Error saving user data: $e');
      throw Exception('Failed to save user data');
    }
  }

  // Get questions for a subject
  Future<List<Map<String, dynamic>>> getQuestions(String subjectId) async {
    try {
      QuerySnapshot querySnapshot = await _firestore
          .collection('questions')
          .where('subjectId', isEqualTo: subjectId)
          .get();

      List<Map<String, dynamic>> questions = [];
      for (var doc in querySnapshot.docs) {
        questions.add({
          'id': doc.id,
          ...doc.data() as Map<String, dynamic>,
        });
      }

      return questions;
    } catch (e) {
      print('Error getting questions: $e');
      throw Exception('Failed to load questions');
    }
  }

  // Save quiz result
  Future<void> saveQuizResult(Map<String, dynamic> resultData) async {
    try {
      await _firestore.collection('results').add({
        ...resultData,
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('Error saving result: $e');
      throw Exception('Failed to save quiz result');
    }
  }

  // Seed sample questions for a subject (development helper)
  Future<void> seedSampleQuestions(String subjectId) async {
    try {
      final batch = _firestore.batch();

      final samples = [
        {
          'question': 'What is 2 + 2?',
          'options': ['3', '4', '5', '22'],
          'correctAnswer': '4',
        },
        {
          'question': 'What is 5 × 6?',
          'options': ['11', '25', '30', '56'],
          'correctAnswer': '30',
        },
        {
          'question': 'What is 9 − 3?',
          'options': ['3', '6', '9', '12'],
          'correctAnswer': '6',
        },
        {
          'question': 'What is 12 ÷ 3?',
          'options': ['3', '4', '6', '9'],
          'correctAnswer': '4',
        },
        {
          'question': 'What is 7 + 5?',
          'options': ['10', '11', '12', '13'],
          'correctAnswer': '12',
        },
      ];

      for (final q in samples) {
        final ref = _firestore.collection('questions').doc();
        batch.set(ref, {
          'subjectId': subjectId,
          ...q,
          'createdAt': FieldValue.serverTimestamp(),
        });
      }

      await batch.commit();
    } catch (e) {
      print('Error seeding sample questions: $e');
      rethrow;
    }
  }
}