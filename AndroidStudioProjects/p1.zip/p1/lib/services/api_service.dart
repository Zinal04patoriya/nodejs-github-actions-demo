import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:p1/config/app_config.dart';
import 'package:p1/models/api_response.dart';
import 'package:p1/models/question_model.dart';
import 'package:p1/models/subject_model.dart';

class ApiService {
  static final String baseUrl = AppConfig.apiBaseUrl;
  final http.Client client;

  ApiService({http.Client? client}) : client = client ?? http.Client();

  // Generic GET request
  Future<ApiResponse<T>> get<T>(
    String endpoint, {
    Map<String, dynamic>? queryParams,
    required T Function(Map<String, dynamic>) fromJsonT,
  }) async {
    try {
      final uri = Uri.parse('$baseUrl/$endpoint').replace(
        queryParameters: queryParams,
      );
      
      final response = await client.get(
        uri,
        headers: await _getHeaders(),
      );

      return _handleResponse<T>(response, fromJsonT);
    } catch (e) {
      debugPrint('API Error (GET $endpoint): $e');
      return ApiResponse<T>(
        success: false,
        message: 'Network error: $e',
      );
    }
  }

  // Generic POST request
  Future<ApiResponse<T>> post<T>(
    String endpoint, {
    required Map<String, dynamic> body,
    required T Function(Map<String, dynamic>) fromJsonT,
  }) async {
    try {
      final response = await client.post(
        Uri.parse('$baseUrl/$endpoint'),
        headers: await _getHeaders(),
        body: jsonEncode(body),
      );

      return _handleResponse<T>(response, fromJsonT);
    } catch (e) {
      debugPrint('API Error (POST $endpoint): $e');
      return ApiResponse<T>(
        success: false,
        message: 'Network error: $e',
      );
    }
  }

  // Get all subjects
  Future<ApiResponse<List<Subject>>> getSubjects() async {
    final response = await get<Map<String, dynamic>>(
      'subjects',
      fromJsonT: (json) => json,
    );

    if (!response.success) {
      return ApiResponse<List<Subject>>(
        success: false,
        message: response.message,
      );
    }

    try {
      final subjects = (response.data!['subjects'] as List)
          .map((item) => Subject.fromJson(item))
          .toList();
      
      return ApiResponse<List<Subject>>(
        success: true,
        message: 'Subjects fetched successfully',
        data: subjects,
      );
    } catch (e) {
      debugPrint('Error parsing subjects: $e');
      return ApiResponse<List<Subject>>(
        success: false,
        message: 'Failed to parse subjects: $e',
      );
    }
  }

  // Get questions by subject
  Future<ApiResponse<List<QuestionModel>>> getQuestionsBySubject(String subjectId) async {
    final response = await get<Map<String, dynamic>>(
      'questions',
      queryParams: {'subjectId': subjectId},
      fromJsonT: (json) => json,
    );

    if (!response.success) {
      return ApiResponse<List<QuestionModel>>(
        success: false,
        message: response.message,
      );
    }

    try {
      final questions = (response.data!['questions'] as List)
          .map((item) => QuestionModel.fromJson(item))
          .toList();
      
      return ApiResponse<List<QuestionModel>>(
        success: true,
        message: 'Questions fetched successfully',
        data: questions,
      );
    } catch (e) {
      debugPrint('Error parsing questions: $e');
      return ApiResponse<List<QuestionModel>>(
        success: false,
        message: 'Failed to parse questions: $e',
      );
    }
  }

  // Helper method to handle API responses
  ApiResponse<T> _handleResponse<T>(
    http.Response response,
    T Function(Map<String, dynamic>) fromJsonT,
  ) {
    final statusCode = response.statusCode;
    final responseBody = jsonDecode(response.body);

    if (statusCode >= 200 && statusCode < 300) {
      try {
        return ApiResponse<T>.fromJson(
          responseBody,
          (data) => fromJsonT(data as Map<String, dynamic>),
        );
      } catch (e) {
        debugPrint('Error parsing response: $e');
        return ApiResponse<T>(
          success: false,
          message: 'Failed to parse response: $e',
        );
      }
    } else {
      final errorMessage = responseBody['message'] ?? 'Unknown error occurred';
      return ApiResponse<T>(
        success: false,
        message: 'Error $statusCode: $errorMessage',
      );
    }
  }

  // Get headers with auth token if available
  Future<Map<String, String>> _getHeaders() async {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    // Add auth token if available
    // final token = await _authService.getToken();
    // if (token != null) {
    //   headers['Authorization'] = 'Bearer $token';
    // }

    return headers;
  }
}
