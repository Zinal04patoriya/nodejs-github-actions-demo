import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../models/user_model.dart';
import '../models/quiz_result.dart';

class UserService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// Get user data by UID
  Future<UserModel?> getUser(String uid) async {
    try {
      DocumentSnapshot snap = await _db.collection("users").doc(uid).get();
      if (snap.exists) {
        return UserModel.fromMap(snap.data() as Map<String, dynamic>);
      }
      return null;
    } catch (e) {
      debugPrint('Error getting user: $e');
      return null;
    }
  }

  /// Update user's total score
  Future<void> updateTotalScore(String uid, int score) async {
    try {
      await _db.collection("users").doc(uid).update({
        'totalScore': FieldValue.increment(score),
        'lastUpdated': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('Error updating total score: $e');
      rethrow;
    }
  }

  /// Save quiz result for a user
  Future<void> saveQuizResult({
    required String userId,
    required String subjectId,
    required String subjectName,
    required int score,
    required int totalQuestions,
  }) async {
    try {
      final result = {
        'subjectId': subjectId,
        'subjectName': subjectName,
        'score': score,
        'totalQuestions': totalQuestions,
        'percentage': (score / totalQuestions * 100).round(),
        'timestamp': FieldValue.serverTimestamp(),
      };

      await _db
          .collection('users')
          .doc(userId)
          .collection('quizResults')
          .add(result);

      // Update user's total score
      await updateTotalScore(userId, score);
    } catch (e) {
      debugPrint('Error saving quiz result: $e');
      rethrow;
    }
  }

  /// Get user's quiz history
  Stream<List<QuizResult>> getUserQuizHistory(String userId) {
    try {
      return _db
          .collection('users')
          .doc(userId)
          .collection('quizResults')
          .orderBy('timestamp', descending: true)
          .snapshots()
          .map((snapshot) => snapshot.docs
              .map((doc) => QuizResult(
                    id: doc.id,
                    subjectId: doc['subjectId'] as String,
                    subjectName: doc['subjectName'] as String? ?? 'Unknown Subject',
                    score: (doc['score'] as num).toInt(),
                    totalQuestions: (doc['totalQuestions'] as num).toInt(),
                    percentage: (doc['percentage'] as num).toInt(),
                    timestamp: (doc['timestamp'] as Timestamp).toDate(),
                  ))
              .toList());
    } catch (e) {
      debugPrint('Error getting quiz history: $e');
      return Stream.value([]);
    }
  }

  /// Get user's statistics
  Future<Map<String, dynamic>> getUserStats(String userId) async {
    try {
      final userDoc = await _db.collection('users').doc(userId).get();
      if (!userDoc.exists) {
        return {
          'totalQuizzes': 0,
          'averageScore': 0,
          'totalCorrect': 0,
          'totalQuestions': 0,
        };
      }

      final resultsSnapshot = await _db
          .collection('users')
          .doc(userId)
          .collection('quizResults')
          .get();

      if (resultsSnapshot.docs.isEmpty) {
        return {
          'totalQuizzes': 0,
          'averageScore': 0,
          'totalCorrect': 0,
          'totalQuestions': 0,
        };
      }

      int totalCorrect = 0;
      int totalQuestions = 0;
      int totalQuizzes = resultsSnapshot.docs.length;

      for (var doc in resultsSnapshot.docs) {
        final data = doc.data();
        totalCorrect += data['score'] as int;
        totalQuestions += data['totalQuestions'] as int;
      }

      return {
        'totalQuizzes': totalQuizzes,
        'averageScore': totalQuizzes > 0 ? (totalCorrect / totalQuizzes).round() : 0,
        'totalCorrect': totalCorrect,
        'totalQuestions': totalQuestions,
        'successRate': totalQuestions > 0 ? (totalCorrect / totalQuestions * 100).round() : 0,
      };
    } catch (e) {
      debugPrint('Error getting user stats: $e');
      rethrow;
    }
  }
}
