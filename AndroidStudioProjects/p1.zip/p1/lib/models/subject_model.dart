import 'package:json_annotation/json_annotation.dart';

part 'subject_model.g.dart';

@JsonSerializable()
class Subject {
  final String id;
  final String name;
  final String description;
  final String? imageUrl;
  final int questionCount;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  const Subject({
    required this.id,
    required this.name,
    required this.description,
    this.imageUrl,
    this.questionCount = 0,
    this.createdAt,
    this.updatedAt,
  });

  /// Create a new instance with updated values
  Subject copyWith({
    String? id,
    String? name,
    String? description,
    String? imageUrl,
    int? questionCount,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Subject(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      imageUrl: imageUrl ?? this.imageUrl,
      questionCount: questionCount ?? this.questionCount,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  /// Convert JSON to Subject
  factory Subject.fromJson(Map<String, dynamic> json) => _$SubjectFromJson(json);
  
  /// Convert Subject to JSON
  Map<String, dynamic> toJson() => _$SubjectToJson(this);
}
