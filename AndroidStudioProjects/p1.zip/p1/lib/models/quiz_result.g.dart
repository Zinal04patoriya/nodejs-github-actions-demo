// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'quiz_result.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

QuizResult _$QuizResultFromJson(Map<String, dynamic> json) => QuizResult(
  id: json['id'] as String,
  subjectId: json['subjectId'] as String,
  subjectName: json['subjectName'] as String,
  score: (json['score'] as num).toInt(),
  totalQuestions: (json['totalQuestions'] as num).toInt(),
  percentage: (json['percentage'] as num).toInt(),
  timestamp: QuizResult._dateTimeFromTimestamp(json['timestamp'] as Timestamp),
);

Map<String, dynamic> _$QuizResultToJson(QuizResult instance) =>
    <String, dynamic>{
      'id': instance.id,
      'subjectId': instance.subjectId,
      'subjectName': instance.subjectName,
      'score': instance.score,
      'totalQuestions': instance.totalQuestions,
      'percentage': instance.percentage,
      'timestamp': QuizResult._dateTimeToTimestamp(instance.timestamp),
    };
