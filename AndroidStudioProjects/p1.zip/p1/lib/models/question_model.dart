import 'package:json_annotation/json_annotation.dart';

part 'question_model.g.dart';

@JsonSerializable()
class QuestionModel {
  final String id;
  final String question;
  final List<String> options;
  final String correctAnswer;
  final String? subjectId;
  final String? difficulty;
  final String? explanation;
  final int? points;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  QuestionModel({
    required this.id,
    required this.question,
    required this.options,
    required this.correctAnswer,
    this.subjectId,
    this.difficulty = 'medium',
    this.explanation,
    this.points = 10,
    this.createdAt,
    this.updatedAt,
  });

  factory QuestionModel.fromJson(Map<String, dynamic> json) => 
      _$QuestionModelFromJson(json);

  Map<String, dynamic> toJson() => _$QuestionModelToJson(this);

  // Helper method to convert Firestore document to QuestionModel
  factory QuestionModel.fromFirestore(
    Map<String, dynamic> data,
    String id,
  ) {
    return QuestionModel(
      id: id,
      question: data['question'] ?? '',
      options: List<String>.from(data['options'] ?? []),
      correctAnswer: data['correctAnswer'] ?? '',
      subjectId: data['subjectId'],
      difficulty: data['difficulty'],
      explanation: data['explanation'],
      points: data['points'] ?? 10,
      createdAt: data['createdAt']?.toDate(),
      updatedAt: data['updatedAt']?.toDate(),
    );
  }

  // Convert to Firestore document
  Map<String, dynamic> toFirestore() {
    return {
      'question': question,
      'options': options,
      'correctAnswer': correctAnswer,
      'subjectId': subjectId,
      'difficulty': difficulty,
      'explanation': explanation,
      'points': points,
      'createdAt': createdAt,
      'updatedAt': updatedAt ?? DateTime.now(),
    };
  }
}
