import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:json_annotation/json_annotation.dart';

part 'user_model.g.dart';

@JsonSerializable()
class UserModel {
  final String uid;
  final String name;
  final String email;
  final DateTime createdAt;
  final DateTime? lastLogin;
  final int totalScore;
  final String? photoUrl;
  final List<String>? completedQuizzes;
  final Map<String, dynamic>? preferences;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    required this.createdAt,
    this.lastLogin,
    this.totalScore = 0,
    this.photoUrl,
    this.completedQuizzes,
    this.preferences,
  });

  /// Convert UserModel to a Firestore Map
  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'email': email,
      'createdAt': createdAt,
      'lastLogin': lastLogin,
      'totalScore': totalScore,
      'photoUrl': photoUrl,
      'completedQuizzes': completedQuizzes,
      'preferences': preferences,
    };
  }

  /// Create UserModel from Firestore Document
  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] as String,
      name: map['name'] as String,
      email: map['email'] as String,
      createdAt: (map['createdAt'] as Timestamp).toDate(),
      lastLogin: map['lastLogin'] != null 
          ? (map['lastLogin'] as Timestamp).toDate() 
          : null,
      totalScore: (map['totalScore'] as num?)?.toInt() ?? 0,
      photoUrl: map['photoUrl'] as String?,
      completedQuizzes: map['completedQuizzes'] != null 
          ? List<String>.from(map['completedQuizzes'] as List) 
          : null,
      preferences: map['preferences'] as Map<String, dynamic>?,
    );
  }

  /// Convert UserModel to JSON
  Map<String, dynamic> toJson() => _$UserModelToJson(this);
  
  /// Create UserModel from JSON
  factory UserModel.fromJson(Map<String, dynamic> json) => 
      _$UserModelFromJson(json);
      
  /// Create a copy of UserModel with updated fields
  UserModel copyWith({
    String? name,
    String? email,
    String? photoUrl,
    int? totalScore,
    DateTime? lastLogin,
    List<String>? completedQuizzes,
    Map<String, dynamic>? preferences,
  }) {
    return UserModel(
      uid: uid,
      name: name ?? this.name,
      email: email ?? this.email,
      createdAt: createdAt,
      lastLogin: lastLogin ?? this.lastLogin,
      totalScore: totalScore ?? this.totalScore,
      photoUrl: photoUrl ?? this.photoUrl,
      completedQuizzes: completedQuizzes ?? this.completedQuizzes,
      preferences: preferences ?? this.preferences,
    );
  }
}
