import 'package:cloud_firestore_platform_interface/cloud_firestore_platform_interface.dart';
import 'package:json_annotation/json_annotation.dart';

part 'quiz_result.g.dart';

@JsonSerializable()
class QuizResult {
  final String id;
  final String subjectId;
  final String subjectName;
  final int score;
  final int totalQuestions;
  final int percentage;
  @JsonKey(fromJson: _dateTimeFromTimestamp, toJson: _dateTimeToTimestamp)
  final DateTime timestamp;

  QuizResult({
    required this.id,
    required this.subjectId,
    required this.subjectName,
    required this.score,
    required this.totalQuestions,
    required this.percentage,
    required this.timestamp,
  });

  factory QuizResult.fromMap(Map<String, dynamic> map, String id) {
    return QuizResult(
      id: id,
      subjectId: map['subjectId'] as String,
      subjectName: map['subjectName'] as String,
      score: map['score'] as int,
      totalQuestions: map['totalQuestions'] as int,
      percentage: map['percentage'] as int,
      timestamp: map['timestamp'] == null
          ? DateTime.now()
          : (map['timestamp'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'subjectId': subjectId,
      'subjectName': subjectName,
      'score': score,
      'totalQuestions': totalQuestions,
      'percentage': percentage,
      'timestamp': timestamp,
    };
  }

  static DateTime _dateTimeFromTimestamp(Timestamp timestamp) => timestamp.toDate();
  static Timestamp _dateTimeToTimestamp(DateTime dateTime) => Timestamp.fromDate(dateTime);

  factory QuizResult.fromJson(Map<String, dynamic> json) => _$QuizResultFromJson(json);
  Map<String, dynamic> toJson() => _$QuizResultToJson(this);
}
