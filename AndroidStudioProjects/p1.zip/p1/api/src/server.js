require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { initFirebase } = require('./firebase');

const app = express();
app.use(cors());
app.use(express.json());

const admin = initFirebase();
const db = admin.firestore();

// Health
app.get('/api/health', (req, res) => {
  res.json({ ok: true, message: 'Quiz API is running' });
});

// Create subject
app.post('/api/subjects', async (req, res) => {
  try {
    const { name, description = '', imageUrl = null } = req.body || {};
    if (!name) return res.status(400).json({ success: false, message: 'name is required' });

    const ref = await db.collection('subjects').add({
      name,
      description,
      imageUrl,
      questionCount: 0,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    const snap = await ref.get();
    res.json({ success: true, data: { id: ref.id, ...snap.data() } });
  } catch (e) {
    console.error('POST /subjects error', e);
    res.status(500).json({ success: false, message: String(e) });
  }
});

// List subjects
app.get('/api/subjects', async (_req, res) => {
  try {
    const qs = await db.collection('subjects').orderBy('createdAt', 'desc').get();
    const items = qs.docs.map((d) => ({ id: d.id, ...d.data() }));
    res.json({ success: true, data: { subjects: items } });
  } catch (e) {
    console.error('GET /subjects error', e);
    res.status(500).json({ success: false, message: String(e) });
  }
});

// Add question to a subject
app.post('/api/questions', async (req, res) => {
  try {
    const { subjectId, question, options, correctAnswer } = req.body || {};
    if (!subjectId) return res.status(400).json({ success: false, message: 'subjectId is required' });
    if (!question) return res.status(400).json({ success: false, message: 'question is required' });
    if (!Array.isArray(options) || options.length < 2) {
      return res.status(400).json({ success: false, message: 'options must be an array with at least 2 items' });
    }
    if (!correctAnswer || !options.includes(correctAnswer)) {
      return res.status(400).json({ success: false, message: 'correctAnswer must be one of the options' });
    }

    const ref = await db.collection('questions').add({
      subjectId,
      question,
      options,
      correctAnswer,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Increment subject questionCount
    await db.collection('subjects').doc(subjectId).set(
      { questionCount: admin.firestore.FieldValue.increment(1), updatedAt: admin.firestore.FieldValue.serverTimestamp() },
      { merge: true }
    );

    const snap = await ref.get();
    res.json({ success: true, data: { id: ref.id, ...snap.data() } });
  } catch (e) {
    console.error('POST /questions error', e);
    res.status(500).json({ success: false, message: String(e) });
  }
});

// Seed three subjects with sample questions
app.post('/api/seed/basic', async (_req, res) => {
  try {
    const batch = db.batch();

    const subjects = [
      { name: 'Mathematics', description: 'Numbers and logic' },
      { name: 'Science', description: 'Physics, Chemistry, Biology' },
      { name: 'History', description: 'Events and timelines' },
    ];

    // Create subjects
    const subjectRefs = subjects.map((s) => db.collection('subjects').doc());
    subjects.forEach((s, i) =>
      batch.set(subjectRefs[i], {
        ...s,
        questionCount: 0,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      })
    );

    await batch.commit();

    // Add questions per subject
    const makeQ = (sid, q, opts, ans) => ({ subjectId: sid, question: q, options: opts, correctAnswer: ans });

    const allQs = [];
    // Maths (5)
    allQs.push(
      makeQ(subjectRefs[0].id, 'What is 2 + 2?', ['3', '4', '5', '22'], '4'),
      makeQ(subjectRefs[0].id, 'What is 7 × 8?', ['42', '54', '56', '64'], '56'),
      makeQ(subjectRefs[0].id, 'Square root of 81?', ['7', '8', '9', '10'], '9'),
      makeQ(subjectRefs[0].id, 'What is 15 − 6?', ['5', '7', '9', '11'], '9'),
      makeQ(subjectRefs[0].id, 'What is 12 ÷ 3?', ['3', '4', '6', '9'], '4')
    );
    // Science (5)
    allQs.push(
      makeQ(subjectRefs[1].id, 'Water chemical formula?', ['H2O', 'CO2', 'O2', 'NaCl'], 'H2O'),
      makeQ(subjectRefs[1].id, 'Planet known as Red Planet?', ['Venus', 'Mars', 'Jupiter', 'Mercury'], 'Mars'),
      makeQ(subjectRefs[1].id, 'Speed of light approx?', ['3e8 m/s', '3e6 m/s', '1e6 m/s', '1e8 m/s'], '3e8 m/s'),
      makeQ(subjectRefs[1].id, 'What gas do plants absorb?', ['O2', 'CO2', 'N2', 'H2'], 'CO2'),
      makeQ(subjectRefs[1].id, 'Unit of force?', ['Joule', 'Newton', 'Watt', 'Pascal'], 'Newton')
    );
    // History (5)
    allQs.push(
      makeQ(subjectRefs[2].id, 'Who discovered America (1492)?', ['Columbus', 'Magellan', 'Cook', 'Vasco da Gama'], 'Columbus'),
      makeQ(subjectRefs[2].id, 'World War II ended in?', ['1943', '1945', '1947', '1950'], '1945'),
      makeQ(subjectRefs[2].id, 'First President of USA?', ['Lincoln', 'Washington', 'Jefferson', 'Adams'], 'Washington'),
      makeQ(subjectRefs[2].id, 'Great Wall is in which country?', ['India', 'China', 'Japan', 'Korea'], 'China'),
      makeQ(subjectRefs[2].id, 'Taj Mahal built by?', ['Akbar', 'Shah Jahan', 'Aurangzeb', 'Humayun'], 'Shah Jahan')
    );

    // Write questions and increment counts
    const qBatch = db.batch();
    const incBy = { Mathematics: 0, Science: 0, History: 0 };

    for (const q of allQs) {
      const ref = db.collection('questions').doc();
      qBatch.set(ref, { ...q, createdAt: admin.firestore.FieldValue.serverTimestamp() });
    }

    await qBatch.commit();

    // Recalculate counts (simple fetch)
    const updates = [];
    for (const [i, name] of ['Mathematics', 'Science', 'History'].entries()) {
      const sid = subjectRefs[i].id;
      const snap = await db.collection('questions').where('subjectId', '==', sid).get();
      updates.push(
        db
          .collection('subjects')
          .doc(sid)
          .set({ questionCount: snap.size, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true })
      );
    }

    await Promise.all(updates);

    const result = subjectRefs.map((r, i) => ({ id: r.id, name: subjects[i].name }));
    res.json({ success: true, message: 'Seeded 3 subjects with questions', data: { subjects: result } });
  } catch (e) {
    console.error('POST /seed/basic error', e);
    res.status(500).json({ success: false, message: String(e) });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Quiz API listening on http://localhost:${PORT}`);
});
