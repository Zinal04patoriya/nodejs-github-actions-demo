const admin = require('firebase-admin');
const path = require('path');
const fs = require('fs');

function initFirebase() {
  if (admin.apps.length) return admin;

  const credsPath = process.env.GOOGLE_APPLICATION_CREDENTIALS || '';
  if (!credsPath) {
    throw new Error('GOOGLE_APPLICATION_CREDENTIALS env var is required and should point to your serviceAccountKey.json');
  }

  const resolved = path.resolve(process.cwd(), credsPath);
  if (!fs.existsSync(resolved)) {
    throw new Error(`Service account file not found at: ${resolved}`);
  }

  const serviceAccount = require(resolved);

  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    // Optionally specify databaseURL or projectId via service account
  });

  return admin;
}

module.exports = { initFirebase };
